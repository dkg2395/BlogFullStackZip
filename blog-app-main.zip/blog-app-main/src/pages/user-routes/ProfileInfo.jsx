import React from 'react'
import Base from '../../components/Base'

function ProfileInfo() {
  return (

    <Base>
      <div>ProfileInfo</div>
    </Base>
  )
}

export default ProfileInfo