import React from 'react'
import AddPost from '../../components/AddPost'
import Base from '../../components/Base'
import { Container } from 'reactstrap'
import NewFeed from '../../components/NewFeed'
const Userdashboard = () => {
  return (

    <Base>

     

    <Container>

       <AddPost />

       

    </Container>

   

    </Base>

  )
}

export default Userdashboard