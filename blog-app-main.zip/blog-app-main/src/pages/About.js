import Base from "../components/Base";

const About = () => {
    return (
        <Base>        
        <h1>this is about page</h1>
        <p>we are building blog website</p>
        </Base>
    );
  };
  
  export default About;
  